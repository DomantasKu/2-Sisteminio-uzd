﻿namespace WinFormsApp4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            failasToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripMenuItem();
            išsaugotiKaipToolStripMenuItem = new ToolStripMenuItem();
            uždarytiToolStripMenuItem = new ToolStripMenuItem();
            pagalbaToolStripMenuItem = new ToolStripMenuItem();
            apieToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox3 = new TextBox();
            label4 = new Label();
            button1 = new Button();
            button2 = new Button();
            label5 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            listBox1 = new ListBox();
            button3 = new Button();
            button4 = new Button();
            label6 = new Label();
            textBox4 = new TextBox();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { failasToolStripMenuItem, pagalbaToolStripMenuItem, apieToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(555, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // failasToolStripMenuItem
            // 
            failasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem1, išsaugotiKaipToolStripMenuItem, uždarytiToolStripMenuItem });
            failasToolStripMenuItem.Name = "failasToolStripMenuItem";
            failasToolStripMenuItem.Size = new Size(48, 20);
            failasToolStripMenuItem.Text = "Failas";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(146, 22);
            toolStripMenuItem1.Text = "Atidaryti";
            toolStripMenuItem1.Click += toolStripMenuItem1_Click;
            // 
            // išsaugotiKaipToolStripMenuItem
            // 
            išsaugotiKaipToolStripMenuItem.Name = "išsaugotiKaipToolStripMenuItem";
            išsaugotiKaipToolStripMenuItem.Size = new Size(146, 22);
            išsaugotiKaipToolStripMenuItem.Text = "Išsaugoti kaip";
            išsaugotiKaipToolStripMenuItem.Click += išsaugotiKaipToolStripMenuItem_Click;
            // 
            // uždarytiToolStripMenuItem
            // 
            uždarytiToolStripMenuItem.Name = "uždarytiToolStripMenuItem";
            uždarytiToolStripMenuItem.Size = new Size(146, 22);
            uždarytiToolStripMenuItem.Text = "Uždaryti";
            uždarytiToolStripMenuItem.Click += uždarytiToolStripMenuItem_Click;
            // 
            // pagalbaToolStripMenuItem
            // 
            pagalbaToolStripMenuItem.Name = "pagalbaToolStripMenuItem";
            pagalbaToolStripMenuItem.Size = new Size(61, 20);
            pagalbaToolStripMenuItem.Text = "Pagalba";
            pagalbaToolStripMenuItem.Click += pagalbaToolStripMenuItem_Click;
            // 
            // apieToolStripMenuItem
            // 
            apieToolStripMenuItem.Name = "apieToolStripMenuItem";
            apieToolStripMenuItem.Size = new Size(43, 20);
            apieToolStripMenuItem.Text = "Apie";
            apieToolStripMenuItem.Click += apieToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 35);
            label1.Name = "label1";
            label1.Size = new Size(86, 15);
            label1.TabIndex = 1;
            label1.Text = "Vardas Pavardė";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 53);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(214, 23);
            textBox1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(239, 35);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 3;
            label2.Text = "Pažymiai";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(239, 53);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(213, 23);
            textBox2.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(458, 35);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 5;
            label3.Text = "Egzamino balas";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(458, 53);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(36, 23);
            textBox3.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(239, 79);
            label4.Name = "label4";
            label4.Size = new Size(188, 15);
            label4.TabIndex = 7;
            label4.Text = "Pažymiai įvedami atskiriant tarpais";
            // 
            // button1
            // 
            button1.Location = new Point(12, 82);
            button1.Name = "button1";
            button1.Size = new Size(100, 26);
            button1.TabIndex = 8;
            button1.Text = "Įvesti";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(118, 82);
            button2.Name = "button2";
            button2.Size = new Size(100, 26);
            button2.TabIndex = 9;
            button2.Text = "Atnaujinti";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 146);
            label5.Name = "label5";
            label5.Size = new Size(151, 15);
            label5.TabIndex = 10;
            label5.Text = "Esami studentai ir rezultatai";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(370, 144);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(67, 19);
            radioButton1.TabIndex = 11;
            radioButton1.TabStop = true;
            radioButton1.Text = "Vidurkis";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(443, 144);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(71, 19);
            radioButton2.TabIndex = 12;
            radioButton2.Text = "Mediana";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(12, 164);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(531, 124);
            listBox1.TabIndex = 13;
            // 
            // button3
            // 
            button3.Location = new Point(12, 294);
            button3.Name = "button3";
            button3.Size = new Size(140, 30);
            button3.TabIndex = 14;
            button3.Text = "Kopijuoti visus";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(158, 294);
            button4.Name = "button4";
            button4.Size = new Size(140, 30);
            button4.TabIndex = 15;
            button4.Text = "Kopijuoti pažymėtą";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 346);
            label6.Name = "label6";
            label6.Size = new Size(250, 15);
            label6.TabIndex = 17;
            label6.Text = "Laukelis kopijavimui, saugojimui ir pastaboms";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(12, 364);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.ScrollBars = ScrollBars.Both;
            textBox4.Size = new Size(531, 177);
            textBox4.TabIndex = 18;
            // 
            // button5
            // 
            button5.Location = new Point(12, 547);
            button5.Name = "button5";
            button5.Size = new Size(100, 25);
            button5.TabIndex = 19;
            button5.Text = "Atidaryti";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(118, 547);
            button6.Name = "button6";
            button6.Size = new Size(100, 25);
            button6.TabIndex = 20;
            button6.Text = "Išsaugoti kaip";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(224, 547);
            button7.Name = "button7";
            button7.Size = new Size(100, 25);
            button7.TabIndex = 21;
            button7.Text = "Spausdinti";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(443, 547);
            button8.Name = "button8";
            button8.Size = new Size(100, 25);
            button8.TabIndex = 22;
            button8.Text = "Valyti";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(555, 576);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(textBox4);
            Controls.Add(label6);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(listBox1);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label5);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MainMenuStrip = menuStrip1;
            MaximizeBox = false;
            Name = "Form1";
            Text = "Studentų žurnalas";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem failasToolStripMenuItem;
        private ToolStripMenuItem pagalbaToolStripMenuItem;
        private ToolStripMenuItem apieToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem išsaugotiKaipToolStripMenuItem;
        private ToolStripMenuItem uždarytiToolStripMenuItem;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox3;
        private Label label4;
        private Button button1;
        private Button button2;
        private Label label5;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private ListBox listBox1;
        private Button button3;
        private Button button4;
        private Label label6;
        private TextBox textBox4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
    }
}