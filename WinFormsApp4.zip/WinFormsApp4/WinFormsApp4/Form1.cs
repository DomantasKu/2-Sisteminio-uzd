﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using System.Drawing.Printing;

namespace WinFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void VidurkiuSkaiciavimas()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                try
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {

                            string[] parts = line.Split(' ');

                            double sum = 0;
                            for (int i = 2; i < parts.Length - 1; i++)
                            {
                                sum += Convert.ToDouble(parts[i]);
                            }
                            double pazymiuVidurkis = sum / (parts.Length - 3);
                            double galutinisBalas = 0.4 * pazymiuVidurkis + 0.6 * Convert.ToDouble(parts[parts.Length - 1]);

                            listBox1.Items.Add($"{parts[0]} {parts[1]} {string.Join(" ", parts.Skip(2).Take(parts.Length - 3))} Egzamino balas: {parts[parts.Length - 1]} Vidurkis: {galutinisBalas:F6}");
                        }
                    }
                    MessageBox.Show("Failas įkeltas!", "Įkelta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Klaida nuskaitant failą\n{ex.Message}", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filePath = "Studentai.txt";

            if (File.Exists(filePath))
            {
                try
                {

                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {

                            string[] parts = line.Split(' ');


                            double sum = 0;
                            for (int i = 2; i < parts.Length - 1; i++)
                            {
                                sum += Convert.ToDouble(parts[i]);
                            }
                            double pazymiuVidurkis = sum / (parts.Length - 3);
                            double galutinisBalas = 0.4 * pazymiuVidurkis + 0.6 * Convert.ToDouble(parts[parts.Length - 1]);

                            listBox1.Items.Add($"{parts[0]} {parts[1]} {string.Join(" ", parts.Skip(2).Take(parts.Length - 3))} Egzamino balas: {parts[parts.Length - 1]} Vidurkis: {galutinisBalas:F6}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Klaida nuskaitant failą\n{ex.Message}", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"Failas {filePath} neegzistuoja.", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            VidurkiuSkaiciavimas();
        }

        private void pagalbaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Irašykite studento vardą, pavardę,\nvisus pažymius, atskirtus tarpais,\nir egzamino balą.\nJeigu norite galite kopijuoti visą informaciją į antrą laukelį išsaugojimui ir/arba komentarų pridėjimui.", "Help", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void apieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Antras praktinis darbas v0.1", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void uždarytiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            VidurkiuSkaiciavimas();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox4.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Sąrašas tuščias, nėra ką spausdinti.", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            PrintDocument printDocument = new PrintDocument();
            PrintDialog printDialog = new PrintDialog();
            PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();

            printDialog.Document = printDocument;
            printPreviewDialog.Document = printDocument;

            int itemIndex = 0;
            int itemsPerPage = 0;

            printDocument.PrintPage += (s, ev) =>
            {
                Font font = new Font("Arial", 12);
                float lineHeight = font.GetHeight(ev.Graphics);

                float yPos = 10;

                while (itemIndex < listBox1.Items.Count)
                {
                    string line = listBox1.Items[itemIndex].ToString();
                    ev.Graphics.DrawString(line, font, Brushes.Black, 10, yPos, new StringFormat());

                    yPos += lineHeight;

                    itemIndex++;

                    itemsPerPage++;

                    if (itemsPerPage >= 20)
                    {
                        ev.HasMorePages = true;
                        return;
                    }
                }

                ev.HasMorePages = false;
            };

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                if (printPreviewDialog.ShowDialog() == DialogResult.OK)
                {
                    printDocument.Print();
                }
            }
        }



        private void button6_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;

                try
                {
                    using (StreamWriter writer = new StreamWriter(filePath))
                    {
                        foreach (var item in listBox1.Items)
                        {
                            writer.WriteLine(item.ToString());
                        }
                    }

                    MessageBox.Show("Failas issaugotas!", "Issaugota", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Klaida saugant faila: {ex.Message}", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void išsaugotiKaipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button6_Click(sender, e);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
                textBox4.AppendText(listBox1.SelectedItem.ToString() + Environment.NewLine);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (var item in listBox1.Items)
            {
                textBox4.AppendText(item.ToString() + Environment.NewLine);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox3.Text))

                SkaiciuotiIrPridetiListbox();
            else
                MessageBox.Show("Užpildykite visus laukelius.", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void SkaiciuotiIrPridetiListbox()
        {
            if (!string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox3.Text))
            {
                string[] pazymiuArray = textBox2.Text.Split(' ');

                if (radioButton1.Checked)
                {
                    // Skaiciuoti vidurki
                    double sum = 0;
                    for (int i = 0; i < pazymiuArray.Length; i++)
                    {
                        sum += Convert.ToDouble(pazymiuArray[i]);
                    }
                    double pazymiuVidurkis = sum / pazymiuArray.Length;

                    double galutinisBalas = 0.4 * pazymiuVidurkis + 0.6 * Convert.ToDouble(textBox3.Text);

                    // Prideti informacija i listBox1
                    listBox1.Items.Add($"{textBox1.Text} {textBox2.Text} Egzamino balas: {textBox3.Text} Vidurkis: {galutinisBalas:F6}");
                }
                else if (radioButton2.Checked)
                {
                    // Skaiciuoti mediana
                    double[] pazymiai = pazymiuArray.Select(s => Convert.ToDouble(s)).ToArray();
                    Array.Sort(pazymiai);

                    double mediana;
                    if (pazymiai.Length % 2 == 0)
                    {
                        int middle1 = pazymiai.Length / 2 - 1;
                        int middle2 = pazymiai.Length / 2;
                        mediana = (pazymiai[middle1] + pazymiai[middle2]) / 2;
                    }
                    else
                    {
                        int middle = pazymiai.Length / 2;
                        mediana = pazymiai[middle];
                    }

                    double galutinisBalas = 0.4 * mediana + 0.6 * Convert.ToDouble(textBox3.Text);

                    // Prideti informacija i listBox1
                    listBox1.Items.Add($"{textBox1.Text} {textBox2.Text} Egzamino balas: {textBox3.Text} Mediana: {mediana:F6}");
                }

                // Isvalyti laukelius
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            else
            {
                MessageBox.Show("Užpildykite visus laukelius.", "Klaida", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

    }
}